City Plan
IART
31 de Março de 2020
Temática 3 - Problema de otimização
Elaborado por: Filipa Senra, Andreia Barreto, Cláudia Martins.

Compile os ficheiros na pasta "src".

Para executar o programa tem 5 opções:
    Main HillClimbing <inputFile> <nRepeat>
    Main SimulatedAnnealing <inputFile> <nRepeat> <T> <alpha>
    Main TabuSearch <inputFile> <nRepeat> <T> <alpha> [<is_tabu_search_random>]
    Main Genetic <inputFile> <nRepeat> <size_population> <percentage_to_keep> <percentage_to_mate> <percentage_to_mutate>
    Main <inputFile> <nRepeat> <size_population> <percentage_to_keep> <percentage_to_mate> <percentage_to_mutate> <T> <Tmin> <alpha>

Poderá ver os resultados no ficheiro results.html (não se esqueça de incluir o ficheiro style.css no mesmo diretório).
